# Arduino IDE Boards Manager Files

Instructions on use here: www.fourboards.co.uk/touchpad-support#installing_arduino
